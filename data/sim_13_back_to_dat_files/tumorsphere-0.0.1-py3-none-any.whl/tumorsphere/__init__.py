"""__init__ module of tumorsphere package.

It contains the version attribute of the package to be used as release version
in the documentation (see release variable at docs/source/conf.py).
"""
__version__ = "0.0.1"
